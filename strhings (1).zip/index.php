<?php
echo "<script type=\"text/javascript\">
	window.location.href=\"./views/home.php\";
</script>";
?>
$(document).on("DOMContentLoaded" , ()=>{
	/*check form inputs*/
	function validate_registration_form(){
		//regular expression
		//regex is a writing notation to create a pattern for your code to search through
		// it uses certain symbols to check if the pattern exists or not
		let name=/^[a-zA-Z ]+$/; 
		let email = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/;
		let username = /^[A-Za-z0-9ñ]+(?:[. _-][A-Za-z0-9]+)*$/;
		let password = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z]{8,}$/;
		let street = /^[A-Za-z0-9]+(?:[. _-][A-Za-z0-9]+)*$/;
		let city = /^[A-Za-z0-9]+(?:[. _-][A-Za-z0-9]+)*$/;
		let country = /^[A-Za-z0-9]+(?:[. _-][A-Za-z0-9]+)*$/;

		let	error= 0;

		if (!$("#uname").val().match(username)) {
			//uses reges to match to the value of the username field
			$("#uname").next().text("Please provide valid username");
			error++;
		} else {
			console.log($('#uname').val());
			$('#uname').next().text('');
		}

		if (!$("#pass").val().match(password)) {
			//password should have contain uppercase,lowercase, numbers and should be at least 8 characters in length
			$("#pass").next().text("Please provide valid password");
			error++;
		} else {
			$('#pass').next().text('');
		}

		if (!$("#email").val().match(email)) {
			//uses reges to match to the value of the username field
			$("#email").next().text("Please provide valid email");
			error++;
		} else {
			$('#email').next().text('');
		}
		if (!$("#street").val().match(street)) {
			//uses reges to match to the value of the username field
			$("#street").next().text("Please provide valid address");
			error++;
		} else {
			$('#street').next().text('');
		}
		if (!$("#city").val().match(city)) {
			//uses reges to match to the value of the username field
			$("#city").next().text("Please provide valid address");
			error++;
		} else {
			$('#city').next().text('');
		}
		if (!$("#country").val().match(country)) {
			//uses reges to match to the value of the username field
			$("#country").next().text("Please provide valid address");
			error++;
		} else {
			$('#country').next().text('');
		}
		if (!$("#firstname").val().match(name)) {
			//uses reges to match to the value of the username field
			$("#firstname").next().text("Please provide valid firstname");
			error++;
		} else {
			$('#firstname').next().text('');
		}
		if ($("#pass").val() != $("#confirm-password").val()) {
			$("#confirm-password").next().text("Passwords should match");
			error++;
			console.log($("#confirm-password").val());
		} else {
			console.log($("#confirm-password").val()+" "+$('#pass').val());
			$("#confirm-password").next().text('');
		}

		if(error>0){
			console.log(error+" errors");
			return false;
		} else {
			console.log(error+" errors");
			return true;
		}
	}

	//actual registration
	$(document).off('click', '#add_user').on('click','#add_user', (e) => {
		if(validate_registration_form()){
			let uname = $('#uname').val();
			let pass = $('#pass').val();
			let firstname = $('#firstname').val();
			let lastname = $('#lastname').val();
			let email = $('#email').val();
			let street = $('#street').val();
			let city = $('#city').val();
			let country = $('#country').val();
			let gender = $('.gender').val();
			let birthday = $('#birthday').val();
				
				console.log('this ran');

			$.ajax({
				"url" : "../controllers/registration-process.php",
				"type" : "POST",
				"data" : {
					'uname' : uname,
					'pass' : pass,
					'firstname' : firstname,
					'lastname' : lastname,
					'email' : email,
					'street' : street,
					'city' : city,
					'country' : country,
					'gender' : gender,
					'birthday' : birthday
				},
				success : (data)=>{
					if(data == "Username exists!"){
						$("#uname").next().html(data);
					}else{
						UIkit.notification({timeout: 1500 , status: 'success', message: '<span uk-icon=\'icon: check\'></span> Registered. '});
						window.setTimeout(function(){location.reload()},2000);
					}
				}
			});
		}
	});


	/*login*/
	$('#login').click(e => {
		let username = $("#username").val();
		let password = $("#password").val();
		$.ajax({
			"url" : "../controllers/login-process.php",
			"type" : "POST",
			"data" : {
				"username" : username,
				"password" : password
			},
			"success" : (data)=>{
				if(data == "login_failed"){
					$("#username").next().text("Incorrect username or password.");
					if($('#login').val() == ""){
						$('#login').val("");
					}
				}else{
					if(data == "admin"){
						UIkit.notification({timeout: 500 , status: 'success', message: '<span uk-icon=\'icon: check\'></span> Logged in. '});
						window.setTimeout(function(){location.reload()},1000);
					}else{
						UIkit.notification({timeout: 500 , status: 'success', message: '<span uk-icon=\'icon: check\'></span> Logged in. '});
						window.setTimeout(function(){location.reload()},1000);
					}	
				}
			}
		});
	});

	

	/*bid now*/
	$(document).off('click', '#bid-now').on('click','#bid-now', function(e){
		e.stopPropagation();
		let id = $(this).attr('data-id');
		let bid = $('#bid_amount').val();
		$.ajax({
			url : "../controllers/bid-process.php",
			type : "POST",
			data : {
				"id" : id,
				"bid" : bid
			},
			success : (data)=>{
				if (data==1) {
					UIkit.notification({timeout: 500 , status: 'success', message: '<span uk-icon=\'icon: check\'></span> Bid posted. '});
				}else if(data==2){
					UIkit.notification({timeout: 500 , status: 'success', message: '<span uk-icon=\'icon: check\'></span> Bid updated. '});
				}else if(data==3){
					UIkit.notification({timeout: 500 , status: 'danger', message: '<span uk-icon=\'icon: check\'></span> Bid unacceptable. '});
				}else if(data==4){
					UIkit.notification({timeout: 500 , status: 'warning', message: '<span uk-icon=\'icon: check\'></span> Retaining bid, since proposed bid is lower than the last.'});
				}else if(data==5){
					UIkit.notification({timeout: 500 , status: 'danger', message: '<span uk-icon=\'icon: check\'></span> Bid unacceptable. '});
				}
				window.setTimeout(function(){location.reload()},1000);
			},
			error : (data)=>{
				UIkit.notification({timeout: 500 , status: 'warning', message: '<span uk-icon=\'icon: check\'></span> Bids must be more than the inital bid or your previous bid. '});
			}
		});
	});

	/*check data id of each item*/
	$(document).ready((e)=>{
		let x = [];
		$('.add-to-follow').each(function (index, val){
			x.push($(this).attr('data-id'));
		});
		$.ajax({
			url : "../controllers/add-followed.php",
			data : {
				"x" : x,
			},
			type : "POST",
			dataType : "JSON",
			cache: false,
			success : (data)=>{
				for (var i = 0; i < data.length; i++)
				{
					$('[data-id='+data[i]+']').first().addClass('uk-text-muted uk-disabled');
				}
			},
			error:(data)=>{
				if(data){
					console.log('err');
				}
			}
		});
	});

	/*add to followed items*/
	$(document).off('click', '#add-to-followed').on('click', '#add-to-followed', (function(e){
		e.stopPropagation();
		let id = $(this).attr('data-id');
		let follow = true;

		$.ajax({
			url : "../controllers/add-followed.php",
			data : {
				"id" : id,
				"follow" : follow
				},
			type : "POST",
			success : (data)=>{
				if(data){
					UIkit.notification({timeout: 500 , status: 'success', message: '<span uk-icon=\'icon: check\'></span> Followed item. '});
					window.setTimeout(function(){location.reload()},1000);
				}else{
					
				}
			}
		});
	}));

	/*remove from followed items*/
		$(document).off('click','#remove-item').on('click','#remove-item', function(e){
			e.stopPropagation;
			let id = $(this).attr('data-id');
			let unfollow = true;
			$.ajax({
				url : "../controllers/add-followed.php",
				data : {
					"id" : id,
					"unfollow" : unfollow
				},
				type : "POST",
				success : (data)=>{
					if(data){
						UIkit.notification({timeout: 500 , status: 'danger', message: '<span uk-icon=\'icon: check\'></span> Unfollowed Item. '});
						window.setTimeout(function(){location.reload()},1000);
					}else{
						console.log('failed to unfollow');
					}
				},
				error:(data)=>{
					console.log(data);
				}
			});
		});


	/*add a new item*/
	$('#post-item-form').on('submit', (function(e) {
		e.stopPropagation();
		$.ajax({
			url: "../controllers/add-process.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
			cache: false,
			processData:false,
			success: function(data){
				if(data=="Upload successful."){
					UIkit.notification({timeout: 500 , status: 'success', message: '<span uk-icon=\'icon: check\'></span> Item information updated. '});
				}else{
					UIkit.notification({timeout: 500 , status: 'danger', message: '<span uk-icon=\'icon: check\'></span> Item information updated. '});
				}
			},
			error: function(e){
				console.log("there was an error "+e);
			}
		});
	}));

	/*edit posted item*/
	$('#edit-form').on('submit', (function(e){
		e.stopPropagation();
		let form = new FormData(this);
		$.ajax({
			url : "../controllers/edit-item-process.php",
			type : "POST",
			data :	form,
			contentType: false,
			cache: false,
			processData:false,
			beforeSend : function(e){
				if($('#new_item_image').val()==0){
					form.append('userImg',$('#cur_item_image'));
				}
			},
			success : function(data){
				if (data) {
					UIkit.notification({timeout: 500 , status: 'success', message: '<span uk-icon=\'icon: check\'></span> Item information updated. '});
					
				}else{
					UIkit.notification({timeout: 500 , status: 'danger', message: '<span uk-icon=\'icon: check\'></span> Seems that there is an error. '});
					
				}
			}
		});
	}));

	/*preview image*/
	showPreview = (objFileInput) =>{
		if (objFileInput.files[0]) {
			let fileReader = new FileReader();
			fileReader.onload = (e) => {
				$("#cur_item_image").attr({ 'src' : e.target.result, 'height' : 200 });
				$(".targetLayer").html("<img src="+e.target.result+" height='200px' >");
			}
			fileReader.readAsDataURL(objFileInput.files[0]);
		}
	}

	/*change password*/
	$(document).off('click', '#change-button').on('click', '#change-button', ((e)=>{
		e.stopPropagation();
		let passwordCheck = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z]{8,}$/;
		let old_password = $('#old_password').val();
		let password = $('#new_password').val();
		let password2 = $('#new_password2').val();

		if(old_password != '' && password != '' && password2 != '' && password.match(passwordCheck)){
			if(password == password2){
				$.ajax({
					url : '../controllers/password-process.php',
					type : 'POST',
					data : {'old_password' : old_password,
							'password' : password,
							'password2' : password2
					},
					success : function(data){
						if(data == 'success'){
							UIkit.notification({timeout: 500, status:'success', message: '<span uk-icon=\'icon: check\'></span> Password changed. '});
							window.setTimeout(function(){location.reload()},1000);
						}else{
							$('#error').html(data);
						}
					}
				});
			}else{
				$('#error').load('../controllers/password-process.php');
			}
		}else{
			$('#error').html('Please, check the fields again');
		}
	}));

	/*update profile*/
	$(document).off('click', '#update-profile').on('click', '#update-profile', (e)=>{
		let street  = $('#street').val();
		let city  = $('#city').val();
		let country  = $('#country').val();
		let email = $('#email').val();

		$.ajax({
			url : '../controllers/profile-process.php',
			type : 'POST',
			data : { 'street' : street ,
					'city' : city,
					'country' : country,
					'email' : email 
			},
			success : (data)=>{
				if (data == 'success') {
					UIkit.notification({timeout: 500 , message: '<span uk-icon=\'icon: check\'></span> Account information updated. '});
					window.setTimeout(function(){location.reload()},1000);
				}
			}
		});
	});

	/*Countdown*/
	$('.clock').countdown('2020/11/14').on('update.countdown', function(event) {
		var $this = $(this).html(event.strftime(''
			+ '<span>%-d</span> day%!d '
			+ '<span>%H</span> hr '
			+ '<span>%M</span> min '
			+ '<span>%S</span> sec'));
	});

	/*fitText*/
	jQuery(".uk-heading-hero").fitText(1.2, { minFontSize: '20px', maxFontSize: '40px' });

	/*ezoom*/
	$('.zoom_01').ezPlus({
    zoomType: 'inner',
    cursor: 'crosshair'
	});

});

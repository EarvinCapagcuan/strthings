<div class="uk-position-relative uk-visible-toggle uk-light" uk-slideshow="animation: push; min-height: 230; max-height: 280; autoplay: true; autoplay-interval: 3000">
	<ul class="uk-slideshow-items">
		<li>
			<div class="uk-position-cover" uk-slideshow-parallax="scale: 1.2,1.2,1">
				<img src="../assets/images/human-lamp.jpg" alt="" uk-cover>
			</div>
			<div class="uk-position-cover" uk-slideshow-parallax="opacity: 0,0,0.2; backgroundColor: #000,#000"></div>
			<div class="uk-overlay uk-overlay-primary uk-position-top-right uk-position-medium uk-text-center">
				<div uk-slideshow-parallax="scale: 1,1,0.8">
					<h2 uk-slideshow-parallax="x: 200,0,0">Hot bids</h2>
					<p uk-slideshow-parallax="x: 400,0,0;">Bids ending in a few hours</p>
				</div>
			</div>
		</li>
		<li>
			<div class="uk-position-cover" uk-slideshow-parallax="scale: 1.2,1.2,1">
				<img src="../assets/images/human-lamp.jpg" alt="" uk-cover>
			</div>
			<div class="uk-position-cover" uk-slideshow-parallax="opacity: 0,0,0.2; backgroundColor: #000,#000"></div>
			<div class="uk-overlay uk-overlay-primary uk-position-bottom-left uk-position-medium uk-text-center">
				<div uk-slideshow-parallax="scale: 1,1,0.8">
					<h2 uk-slideshow-parallax="x: 200,0,0">Hot bids</h2>
					<p uk-slideshow-parallax="x: 400,0,0;">Bids ending in a few hours</p>
				</div>
			</div>
		</li>
		<li>
			<div class="uk-position-cover" uk-slideshow-parallax="scale: 1.2,1.2,1">
				<img src="../assets/images/human-lamp.jpg" alt="" uk-cover>
			</div>
			<div class="uk-position-cover" uk-slideshow-parallax="opacity: 0,0,0.2; backgroundColor: #000,#000"></div>
			<div class="uk-overlay uk-overlay-primary uk-position-bottom-right uk-position-medium uk-text-center">
				<div uk-slideshow-parallax="scale: 1,1,0.8">
					<h2 uk-slideshow-parallax="x: 200,0,0">Hot bids</h2>
					<p uk-slideshow-parallax="x: 400,0,0;">Bids ending in a few hours</p>
				</div>
			</div>
		</li>
	</ul>
	<a class="uk-position-center-left uk-position-small uk-hidden-hover" href="#" uk-slidenav-previous uk-slideshow-item="previous"></a>
	<a class="uk-position-center-right uk-position-small uk-hidden-hover" href="#" uk-slidenav-next uk-slideshow-item="next"></a>
</div>
<?php
$page = "admin";
require_once "../partials/template.php";
function get_page_content() {
global $conn; ?>
	
<?php if(isset($_SESSION['user']) && $_SESSION['user']['level'] == 1) { ?>
	<div class="uk-container-expand uk-padding-remove uk-margin-remove">
		<ul class="uk-breadcrumb uk-width-1-1@m uk-background-muted uk-margin-remove uk-padding-small">
			<li><a href="./admin-page.php">Accounts</a></li>
			<li><span>Designate another Admin</span></li>
		</ul>
	</div>
	<div class="uk-container uk-padding-small">
			<h3 class="uk-heading-line"><span>Designate Another Admin</span></h3>
			<div class="uk-width-1-1@m">
				<table class="uk-table uk-table-striped">
					<thead class="uk-background-secondary uk-text-muted">
						<tr>
							<td>Username</td>
							<td>First Name</td>
							<td>Last Name</td>
							<td>Email</td>
							<td>Role</td>
							<td>Action</td>
						</tr>
					</thead>
					<tfoot>
						<tr><td colspan="6" class="uk-text-right"><em>End of Record</em></td></tr>
					</tfoot>
					<tbody>
						<?php
							$get_users_query = "SELECT u.id, u.username, u.firstname, u.lastname, u.email, r.level AS level FROM users u JOIN user_level r ON (u.level = r.id);";
							$user_list = mysqli_query($conn, $get_users_query);
							foreach($user_list as $indiv_user) { ?>
							<tr>
								<td><?php echo $indiv_user['username']; ?></td>
								<td><?php echo $indiv_user['firstname']; ?></td>
								<td><?php echo $indiv_user['lastname']; ?></td>
								<td><?php echo $indiv_user['email']; ?></td>
								<td><?php echo $indiv_user['level']; ?></td>
								<td>
									<?php
									$id = $indiv_user['id'];
									if($indiv_user['level'] == 'Admin'){
										echo "<a href='../controllers/grant_admin.php?id=$id' class='uk-button uk-button-secondary'>Revoke Admin</a>";
									} else {
										echo "<a href='../controllers/grant_admin.php?id=$id' class='uk-button uk-button-default'>Make Admin</a>";
									}
									?>
								</td>
							</tr>
						<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
<?php } else {
	header("Location: ./lost.php");
		}
	?>
<?php } ?>
<?php
require_once "../partials/template.php";

function get_page_content(){ 
	if (!isset($_SESSION['user']) || (isset($_SESSION['user']) && $_SESSION['user']['level'] == 2)) {
		global $conn; 
		$slqQ = "SELECT * FROM users WHERE id = ".$_SESSION['user']['id']." ";
		$sql = mysqli_fetch_assoc(mysqli_query($conn, $slqQ));
		$address = $sql['street'].", ".$sql['city'].", ".$sql['country'];
		$bidId = $_GET['id'];
		$selectQ = "SELECT * FROM bids WHERE id = $bidId ";
		$selectL = mysqli_query($conn, $selectQ);
		$select = mysqli_fetch_assoc($selectL);
		$itemId = $select['item_id'];
		?>
		<div class="uk-container uk-padding-small">
			<h3 class="uk-heading-line"><span>Check Out Item</span></h3>
			<div class="uk-width-2-3@m uk-margin-auto">
				<form class="uk-form" method="POST" action="../controllers/placeorder.php">
					<h4>Shipping address</h4>
					<div class="uk-width-1-2">
					</div>
					<input type="text" class="uk-input" id="addressLine1" name="addressLine1" value="<?php echo $address; ?>">
					<h4>Order Summary</h4>
					<div class="uk-child-width-1-2@m uk-child-width-1-1@s" uk-grid>
						<div class="uk-width-1-2@m uk-width-1-1@s">
							<h4>Item</h4>
							<?php $itemQ = "SELECT * FROM items it JOIN bids bi ON it.id = bi.item_id WHERE it.id = $itemId ";
							$item = mysqli_fetch_assoc(mysqli_query($conn, $itemQ));
							?>
							<div uk-grid>
								<div class="uk-width-2-3@m uk-text-large" uk-leader><?php echo $item['name'];?></div>
								<div><?php echo "&#8369; ".$item['highest_bid']; ?></div>
								<div class="uk-width-2-3@m" uk-leader>Subtotal</div>
								<div><?php echo "&#8369; ".$item['highest_bid']; ?></div>
								<div class="uk-width-2-3@m" uk-leader>Shipping</div>
								<div><em>free</em></div>
								<div class="uk-width-2-3@m" uk-leader>Total</div>
								<div class="uk-text-bold"><?php echo "&#8369; ".$select['bid_amt']; ?></div>
							</div>
						</div>
						<div class="uk-width-1-2@m  uk-width-1-1@s">
							<h4>Payment Method</h4>
							<select class="uk-select" id="payment_mode" name="payment_mode">
								<?php 
								$payment_mode_query = "SELECT * FROM payment_modes;";
								$payment_modes = mysqli_query($conn, $payment_mode_query);
								foreach($payment_modes as $payment_mode){
									extract($payment_mode);
									echo "<option value='$id'>$name</option>";
								}
								?>
							</select>
						</div>
					</div>
					<hr>
					<button type="submit" class="uk-button uk-button-default">Place order now</button>
					<input type="text" class="uk-hidden" id="itemId" name="itemId" value="<?php echo $select['item_id']; ?>">
					<input type="text" class="uk-hidden" id="bidId" name="bidId" value="<?php echo $bidId; ?>">
				</form>
			</div>
<?php } else { ?>
	<script type="text/javascript">
		window.location.href = './lost.php';
	</script>
<?php } ?>
<?php } ?>
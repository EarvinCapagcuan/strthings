<?php
$page = "account";
require_once "../partials/template.php"; ?>
<?php function get_page_content(){ 
	if (isset($_SESSION['user']) && $_SESSION['user']['level'] == 1){
		global $conn; ?>

	<div class="uk-container-expand uk-padding-remove uk-margin-remove">
		<ul class="uk-breadcrumb uk-width-1-1@m uk-background-muted uk-margin-remove uk-padding-small">
			<li><a href="./admin-page.php">Admin</a></li>
			<li><span>Orders</span></li>
		</ul>
	</div>
		<div class="uk-container uk-padding-small">
			<h3 class="uk-heading-line"><span>Orders Admin Page</span></h3>
			<div class="uk-width-expand">
				<ul class="uk-subnav uk-subnav-pill uk-margin-auto uk-flex uk-flex-around" uk-switcher="animation: uk-animation-slide-left-medium, uk-animation-slide-right-medium">
					<li><a href="#">Pending Orders</a></li>
					<li><a href="#">Completed Orders</a></li>
				</ul>
				<ul class="uk-switcher">
					<!-- pending -->
					<li>
						<div class="uk-width-1-1@m uk-flex uk-flex-column">
							<h4 class="uk-heading-line"><span>Pending</span></h4>
							<table class="uk-table uk-table-striped uk-margin-remove">
								<thead class="uk-button-secondary">
									<tr class="uk-text-center uk-child-width-1-4@m uk-child-width-1-3@s">
										<td>Transaction Code</td>
										<td>Status</td>
										<td class="uk-visible@s">Purchase Date</td>
										<td>Actions</td>
									</tr>
								</thead>
								<tfoot>
									<tr><td><em>End of Record</em></td></tr>
								</tfoot>
								<tbody>
									<?php
									$order_query = "SELECT o.id, o.transaction_code, o.purchase_date, s.status_name AS status FROM orders o JOIN statuses s ON (o.status_id = s.id) WHERE o.status_id = 1";
									$orders = mysqli_query($conn, $order_query);
									foreach($orders as $indiv_order){?>
										<tr class="uk-text-center uk-child-width-1-4@m uk-child-width-1-3@s">
											<td><?php echo $indiv_order['transaction_code']; ?></td>
											<td><?php echo $indiv_order['status']; ?></td>
											<td class="uk-visible@s"><?php echo $indiv_order['purchase_date']; ?></td>
											<td><?php if($indiv_order['status'] == "Pending") {?>
												<a href="../controllers/complete-order.php?id=<?php echo $indiv_order['id']?>" class="uk-button uk-button-secondary">Complete</a>
												<?php } ?></td>
										</tr>
										<?php }	?>
								</tbody>
							</table>
						</div>
					</li>
					<!-- completed -->
					<li>
						<div class="uk-width-1-1@m uk-flex uk-flex-column">
							<h4 class="uk-heading-line"><span>Completed</span></h4>
							<table class="uk-table uk-table-striped">
								<thead class="uk-button-secondary">
									<tr class="uk-text-center">
										<td>Transaction Code</td>
										<td>Status</td>
										<td>Purchase Date</td>
									</tr>
								</thead>
								<tfoot>
									<tr><td><em>End of Record</em></td></tr>
								</tfoot>
								<tbody>
									<?php
									$order_query2 = "SELECT o.id, o.transaction_code, o.purchase_date, s.status_name AS status FROM orders o JOIN statuses s ON (o.status_id = s.id) WHERE o.status_id = 2";
									$orders2 = mysqli_query($conn, $order_query2);
									foreach($orders2 as $indiv_order){?>
										<tr class="uk-text-center">
											<td><?php echo $indiv_order['transaction_code']; ?></td>
											<td><?php echo $indiv_order['status']; ?></td>
											<td><?php echo $indiv_order['purchase_date']; ?></td>
										</tr>
									<?php }	?>
								</tbody>
							</table>
						</div>
					</li>
				</ul>
			</div>
		<span class="uk-padding-small uk-background-muted uk-align-right ">
			<a href="#" uk-totop uk-scroll></a>
		</span>
		</div>
	<?php } else {
		header("Location: ./lost.php");
	} ?>
<?php } ?>

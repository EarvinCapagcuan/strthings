<?php
$page = "edit";
require_once "../partials/template.php";
function get_page_content(){
	global $conn;
	$itemId = $_GET['id'];
	if(isset($_SESSION['user']) && $_SESSION['user']['level'] == 1) { 
		$selectQ = "SELECT * FROM items WHERE id = $itemId ";
		$editItem = mysqli_query($conn, $selectQ);
		$value = mysqli_fetch_assoc($editItem);
	?>

	<div class="uk-container-expand uk-padding-remove uk-margin-remove uk-visible@s">
		<ul class="uk-breadcrumb uk-width-1-1@m uk-background-muted uk-margin-remove uk-padding-small">
			<li><a href="./categories.php">Bids</a></li>
			<li><a href="./posted-items.php">Review Posted Bids</a></li>
			<li><span>Item: <?php echo $value['name']; ?></span></li>
		</ul>
	</div>
	<div class="uk-container uk-padding-small" data-id="<?php echo $value['id'] ?>" uk-overflow-auto>
		<form id="edit-form" method="POST" enctype="multipart/form-data">
			<h3>Edit <?php echo $value['name']; ?></h3>
			<hr>
			<div uk-grid>
				<div class="uk-width-1-2@m">
					<label class="uk-head">Name: </label>
					<input type="text" class="uk-input" id="item_name" name="item_name" value="<?php echo $value['name'];?>"></input>
					<label class="uk-head">Initial Bid: </label>
					<input type="text" class="uk-input" id="item_initial_bid" name="item_initial_bid" value="<?php echo $value['initial_bid'];?>" placeholder="<?php echo $value['initial_bid']; ?>">
					<label class="uk-head">Description: </label>
					<textarea class="uk-textarea" id="item_desc" name="item_desc" placeholder="<?php echo $value['description'];?>"><?php echo $value['description'];?></textarea>
					<div class="uk-form-controls">
						<label class="uk-form-label" for="category">Item category</label>
						<select class="uk-select" id="category" name="category">
							<option value="" disabled selected>Select category</option>
							<option value="1">Furniture</option>
							<option value="2">Painting</option>
							<option value="3">Ornaments</option>
							<option value="4">Miscellaneous</option>
						</select>
					</div>
				</div>
				<div class="uk-width-1-2@m">
					<div class="uk-flex uk-flex-column uk-margin-auto uk-padding-small uk-width-1-1@m uk-column-1-2@m uk-column-1-1@s" uk-form-custom>
						<input type="file" id="new_item_image" height="200px" name="new_item_image" id="new_item_image" onChange="showPreview(this);">
						<img src="<?php echo $value['image_path']; ?>" height="100px" id="cur_item_image" name="cur_item_image" class="uk-width-1-1 uk-margin-top upload-preview"><br>
						<button class="uk-button" type="button" tabindex="-1">Click to upload: </button>
					</div>
				</div>
			</div>
			<input type="text" class="uk-hidden" name="itemId" id="itemId" value="<?php echo $itemId; ?>">
			<button type="submit" class="uk-button uk-align-center" id="save-change">Save Changes</button>
		</form> 
	</div>
<?php }
} ?>
<?php
$page = "bid";
require_once "../partials/template.php";

function get_page_content() {
	global $conn;
	if(isset($_SESSION['user']) && $_SESSION['user']['level'] == 1){
		$listQ = "SELECT * FROM statuses st, items it WHERE st.id = it.item_status";
		$listL = mysqli_query($conn, $listQ); ?>
		<table class="uk-table">
			<thead>
				<th>
					<tr>
						<td>Name</td>
						<td>Initial Bid</td>
						<td>Highest Bid</td>
						<td>Status</td>
					</tr>
				</th>
			</thead>
			<?php
			foreach ($listL as $key => $list) { ?>
				<tr>
					<td><?php echo $list['name']; ?></td>
					<td><?php echo $list['initial_bid']; ?></td>
					<td><?php echo $list['highest_bid']; ?></td>
					<td><?php echo $list['status_name']; ?></td>
				</tr>	
				<?php
			} ?>
		</table>
		<?php
	}else{ ?>
		<script type="text/javascript">
			window.location.href="./lost.php";
		</script>
	<?php } 
}
?>
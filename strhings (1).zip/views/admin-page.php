<?php
$page = "account";
require_once "../partials/template.php";
function get_page_content(){
	global $conn;
if(isset($_SESSION['user']) && $_SESSION['user']['level'] == 1){
?>
<div class="uk-container uk-padding-small">
	<h3 class="uk-heading-line">Admin</h3>
	<div class="uk-margin-auto uk-child-width-1-4@m" uk-grid>
		<div>
			<h4>Admin Information</h4>
			<ul class="uk-list uk-child-width-expand">
				<li>Name: <?php echo $_SESSION['user']['firstname']." ".$_SESSION['user']['lastname']; ?></li>
				<li>Email: <?php echo $_SESSION['user']['email']; ?></li>
			</ul>
		</div>
		<div>
			<h4>Bids</h4>
			<ul class="uk-list">
				<li><a href="./add-item.php" class="uk-button uk-button-secondary uk-link">Open a bid</a></li>
				<li><a href="./posted-items.php" class="uk-button uk-button-secondary uk-link">Modify a bid</a></li>
				<li><a href="./close-bid.php" class="uk-button uk-button-secondary uk-link">Close a bid</a></li>
			</ul>
		</div>
		<div>
			<h4>Orders</h4>
			<ul class="uk-list">
				<li><a href="./complete-order.php" class="uk-button uk-button-secondary">Orders</a></li>
			</ul>
		</div>
		<div>
			<h4>Accounts</h4>
			<ul class="uk-list  uk-child-width-expand">
				
				<li><a href="./designate-users.php" class="uk-button uk-button-secondary uk-link">Designate another Admin</a></li>
				<li><a href="./update-profile.php" class="uk-button uk-button-secondary uk-link">Update your information</a></li>
		</div>
	</div>

</div>

<?php }else{ ?>
	<script type="text/javascript">
		window.location.href='./lost.php';
	</script>
<?php }
} ?>
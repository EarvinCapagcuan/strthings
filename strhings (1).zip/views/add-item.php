<?php
$page = "add";
require_once "../partials/template.php";
function get_page_content(){
	if(isset($_SESSION['user']) && $_SESSION['user']['level']==1){
		global $conn;
		?>

		<div class="uk-container-expand uk-padding-remove uk-margin-remove uk-visible@s">
			<ul class="uk-breadcrumb uk-width-1-1@m uk-background-muted uk-margin-remove uk-padding-small">
				<li><a href="./categories.php">Bids</a></li>
				<li><span>Open a Bid</span></li>
			</ul>
		</div>
		<div class="uk-container uk-padding-small">
			<form class="uk-form-horizontal uk-width-2-3@m uk-margin-auto" id="post-item-form" method="POST"  enctype="multipart/form-data">
				<h3 class="uk-heading-line"><span>Add an item</span></h3>
				<div class="uk-margin">
					<label class="uk-form-label" for="item">Item name</label>
					<div class="uk-form-controls">
						<input type="text" class="uk-input" name="item" id="item" placeholder="Name of the item"></input>
					</div>
				</div>
				<div class="uk-margin">
					<label class="uk-form-label" for="desc">Item description</label>
					<div class="uk-form-controls">
						<textarea type="text" class="uk-input" name="desc" id="desc" placeholder="Tell us something about the item"></textarea>
					</div>
				</div>
				<div class="uk-margin">
					<label class="uk-form-label" for="initial-bid">Initial bid</label>
					<div class="uk-form-controls">
						<input type="number" class="uk-input" name="initial_bid" id="initial_bid" placeholder="What is the propsed intial bid"></input>
					</div>
				</div>
				<div class="uk-margin">
					<label class="uk-form-label" for="category">Item category</label>
					<div class="uk-form-controls">
						<select class="uk-select" id="category" name="category">
							<option value="" disabled selected>Select category</option>
							<option value="1">Furniture</option>
							<option value="2">Painting</option>
							<option value="3">Ornaments</option>
							<option value="4">Miscellaneous</option>
						</select>
					</div>
				</div>
				<div class="uk-margin">
					<label class="uk-form-label" for="category">Bid End Date </label>
					<div class="uk-form-controls">
						<input type="date" class="uk-textarea" name="end_date" id="end_date">
					</div>
				</div>
				<div class="uk-margin">
					<label class="uk-form-label">Upload a photo of the item</label>
					<div class="uk-form-controls uk-flex uk-flex-column">
						<input type="file" id="userImage" name="userImage targetLayer" placeholder="Click to browse" onChange="showPreview(this);">
						<span class="targetLayer uk-width-expand uk-margin-top uk-align-center"></span>
					</div>
				</div>
				
				<button class="uk-button uk-button-default uk-align-center" type="submit" id="post-item" onclick="UIkit.notification({message: '<span uk-icon=\'icon: Added Item\'></span> Message with an icon'})">Post item</button>
			</form>
		</div>

	<?php }else{ ?>
		<script type="text/javascript">
			window.location.href="./lost.php";	
		</script>		
<?php }
}
?>
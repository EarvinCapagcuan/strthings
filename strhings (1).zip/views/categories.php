<?php
$page = "categories";
require_once "../partials/template.php";

function get_page_content(){ 
	global $conn;
	$categoryQ = "SELECT * FROM categories";
	$categoryL = mysqli_query($conn, $categoryQ);

	?>
	<div class="uk-container uk-margin-auto uk-padding-small">
		<div uk-gird class="">
			<h3 class="uk-head uk-text-center"><span>Categories</span></h3>
			<div class="uk-button-group uk-flex uk-flex-center cat-cont">
				<ul class="uk-tab">
					<li><a href="./categories.php" class='uk-link-text cat-link uk-active'>All</a></li>&nbsp;
					<?php 
					foreach ($categoryL as $key => $value) {
						echo "<li><a href='./categories.php?category_id=".$value['id']."' class='uk-link-text cat-link'>".$value['name']."</a><li>&nbsp;";
					}
					?>
				</ul>
			</div>
		</div>
		
	</div>
</div>

<div class="uk-container uk-padding-small">
	<h3 class="uk-heading-line">
		<span>
			<?php if(isset($_GET['category_id'])) {
				$catId = $_GET['category_id'];
				$catNameQ = "SELECT cat.name FROM categories cat JOIN items it ON it.category_id = cat.id WHERE it.category_id = $catId";
				$catName = mysqli_fetch_assoc(mysqli_query($conn, $catNameQ));
				extract($catName);
				echo $name;
			}else{
				echo "All Items";
			} ?>
		</span>
	</h3>
	<div class="uk-flex" uk-grid>
		<div class="uk-width-1-6@m uk-width-1-3@s uk-margin-auto">
			<ul class="uk-tab">
				<li><a class="uk-link-text sort-item" href="../controllers/sort.php?sort=desc">Sort by highest bid</a></li>
				<li><a class="uk-link-text sort-item" href="../controllers/sort.php?sort=asc">Sort by lowest bid</a></li>
				<li><a class="uk-link-text sort-item" href="../controllers/sort.php?sort=count">Sort by bid count</a></li>
				<li><a class="uk-link-text sort-item" href="../controllers/sort.php?sort=status">Sort by status</a></li>
			</ul>
		</div>
		<div class="uk-width-expand uk-margin-auto">
			<div class="uk-child-width-1-4@m uk-child-width-1-2@s  uk-margin-auto" uk-grid>
				<?php
				$itemQ = "SELECT * FROM items";

				if(isset($_GET['category_id'])) {
					$itemQ .= " WHERE category_id = ".$_GET['category_id'];
				}
				if(isset($_SESSION['sort'])) {
					$itemQ .= $_SESSION['sort'];
				}
				$itemL = mysqli_query($conn, $itemQ);

				foreach ($itemL as $key => $value) { ?>
					<div class="uk-card uk-card-hover uk-padding-small uk-visible-toggle uk-animation-toggle">
						<a href="./item-view.php?id=<?php echo $value['id']."&category_id=".$value['category_id'] ?>" class="uk-link-reset">
							<div class="uk-card-media-top uk-cover-container">
								<img src="<?php echo $value['image_path']; ?>" uk-cover>
								<canvas width="200" height="180" class="border"></canvas>
						<div class="uk-badge uk-label uk-position-bottom-left">Bids <?php echo $value['bid_count'] ?></div>
							</div>
							<div class="uk-card-body uk-padding-remove">
								<span class="uk-card-title"><?php echo $value['name']; ?></span><br>
								<?php if($value['initial_bid'] > $value['highest_bid']){ ?>
									<span>Initial bid: $ <?php echo $value['initial_bid']; ?></span><br>
								<?php }else{ ?>
									<span>Highest bid: $ <?php echo $value['highest_bid']; ?></span><br>
								<?php } ?>
								<span>Bidding ends in <br><i class="clock"></i></span><br>
							</div>
						</a> <?php if(isset($_SESSION['user']) && $_SESSION['user']['level']==2) { ?>
						<div class="uk-position-top-right uk-padding-remove uk-overlay uk-overlay-default uk-animation-slide-top">
							<button id="add-to-followed" class="uk-hidden-hover uk-button uk-button-text add-to-follow" data-id="<?php echo $value['id']; ?>"></button>
						</div><?php } ?>
					</div><?php
				 }	?>	
			</div>
		</div>
	</div>
</div>
<?php } ?>
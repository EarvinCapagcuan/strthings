<?php
require_once "../partials/template.php";

function get_page_content(){
if (isset($_SESSION['user']) && $_SESSION['user']['level'] == 1) {
	global $conn; 
	$id = $_SESSION['user']['id']; ?>

	<div class="uk-container-expand uk-padding-remove uk-margin-remove">
		<ul class="uk-breadcrumb uk-width-1-1@m uk-background-muted uk-margin-remove uk-padding-small">
			<li><a href="./categories.php">Bids</a></li>
			<li><span>Edit Bids</span></li>
		</ul>
	</div>
	<div class="uk-container uk-padding-small">
		<h3 class="uk-heading-line"><span>Your posted items</span></h3>
		<div class="uk-margin-auto" uk-grid>
			<table class="uk-table uk-table-striped">
				<?php
				$yourItemsQ = "SELECT * FROM items WHERE seller_id = $id ";
				$yourItems = mysqli_query($conn, $yourItemsQ);
				?>
				<thead class="uk-background-secondary">
					<tr>
						<th>Item Name</th>
						<th>Initial Bid</th>
						<th>Current Highest Bid</th>
						<th>Date Posted</th>
						<th>Actions</th>
					</tr>
				</thead>
				<tfoot>
					<tr>
						<td colspan="5" class="uk-text-right"><em>End of Record</em></td>
					</tr>
				</tfoot>
				<tbody class="uk-text-center">
					<?php
					foreach ($yourItems as $key => $value) {
						echo "<tr data-id=".$value['id'].">
								<td class='uk-text-left'>".$value['name']."</td>
								<td>".$value['initial_bid']."</td>
								<td>".$value['highest_bid']."</td>
								<td>".$value['date_posted']."</td>
								<td>
									<a class='uk-button uk-button-secondary' id='edit-item' href='./edit-item-form.php?id=".$value['id']."' >Edit Item information</a>
								</td>
							</tr>";
					}	?>
				</tbody>
			</table>
		</div>
	</div>
<?php 
	$selectQ = "SELECT * FROM items";
	$selectItems = mysqli_query($conn, $selectQ);
	foreach($selectItems as $key => $value) { ?>
	<div id="edit-modal-<?php echo $value['id'] ?>" class="uk-modal-container" uk-modal>

		</div>
	</div>
<?php
	}
}else{ ?>
			<script type="text/javascript">
			window.location.href="./lost.php";	
		</script>	
<?php }
} ?>
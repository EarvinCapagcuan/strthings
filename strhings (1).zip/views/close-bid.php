<?php
$page = "close";
require_once "../partials/template.php";
function get_page_content(){ 
if (isset($_SESSION['user']) && $_SESSION['user']['level'] == 1) {
	global $conn;
	$listBidQ = "SELECT * FROM items WHERE item_status = 4";
	$listBid = mysqli_query($conn, $listBidQ); ?>

<div class="uk-container-expand uk-padding-remove uk-margin-remove uk-visible@s">
	<ul class="uk-breadcrumb uk-width-1-1@m uk-background-muted uk-margin-remove uk-padding-small">
		<li><a href="./categories.php">Bids</a></li>
		<li><span>Close an ongoing Bid</span></li>
	</ul>
</div>
<div class="uk-container uk-padding">
	<h3 class="uk-heading-line"><span>Close Bid</span></h3>
	<div uk-grid class="uk-margin-auto">
		<table class="uk-table uk-table-striped">
			<thead class="uk-background-secondary uk-text-center">
				<tr>
					<th>Item Name</th>
					<th>Highest Bid</th>
					<th>Highest Bidder</th>
					<th>Close Bid</th>
				</tr>
			</thead>
			<tfoot class="uk-text-right">
				<tr><td colspan="4"><em>End of Record</em></td></tr>
			</tfoot>
			<tbody>
				<?php foreach ($listBid as $key => $item) {
					$x = $item['id'];
					$checkHighestQ = "SELECT * FROM bids WHERE item_id = $x AND bid_status = 4 ORDER BY bid_amt DESC LIMIT 1";
					$checkHighest = mysqli_query($conn, $checkHighestQ);
					$highestBid = mysqli_fetch_assoc($checkHighest);

					foreach ($checkHighest as $i => $value) {
						$itemId = $value['item_id'];
						$itemNameQ = "SELECT it.name FROM items it JOIN bids bi ON it.id = bi.item_id WHERE it.id = $itemId ";
						$itemNameL = mysqli_query($conn, $itemNameQ);
						$itemName = mysqli_fetch_assoc($itemNameL);

						$userId = $value['user_id'];
						$bidderQ = "SELECT * FROM users usr JOIN bids bi ON usr.id = bi.user_id WHERE usr.id = $userId ";
						$bidderL = mysqli_query($conn, $bidderQ);
						$bidderName = mysqli_fetch_assoc($bidderL);
					?>
						<tr>
							<td><?php echo $itemName['name']; ?></td>
							<td><?php echo $value['bid_amt']; ?></td>
							<td><?php echo $bidderName['username']; ?></td>
							<td><a href="../controllers/close-bid-process.php?id=<?php echo $highestBid['id']; ?>" class="uk-button uk-button-secondary">Close Bid</a></td>
						</tr>
				<?php
					}
				} ?>
			</tbody>
		</table>
		
	</div>
</div>
<?php }else{ ?>
			<script type="text/javascript">
			window.location.href="./lost.php";	
		</script>	
<?php }
} ?>

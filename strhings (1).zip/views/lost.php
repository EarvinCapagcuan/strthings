<?php
require_once "../partials/template.php";
function get_page_content(){ ?>
<div class="uk-container uk-padding">
	<h3 class="uk-heading">Error.</h3>
	<p>Are..you..lost little lamb?</p>
</div>
<?php } ?>
<footer id="main-footer" class="uk-contaier-expand uk-padding-small uk-margin-top uk-background-secondary uk-light">
	<div class="uk-child-width-1-3@m uk-child-width-1-1@s uk-padding-bottom-remove uk-flex uk-margin-auto" uk-grid>
		<div class="uk-flex uk-margin-auto uk-flex-column uk-padding-remove">
			<h3 class="uk-align-center">Strange Things</h3>	
			<p class="uk-text-center">Browse through millions of unique products created by independent artists from all over the world. Each product is manufactured, on-demand, at one of our 14 global production facilities and will be on its way to you within 3 - 4 business days.</p>
		</div>
		<div class="uk-text-center uk-padding-remove">
			<h3>Check our social media</h3>
			<ul class="uk-list">
				<div class="uk-flex uk-flex-around">
				<li><a href="https://www.facebook.com" uk-icon="icon:facebook;ratio:2">	</a></li>
				<li><a href="https://www.linkedin.com/in/julian-earvin-king-capagcuan-84bbb713a" uk-icon="icon:linkedin;ratio:2"></a></li>
				<li><a href="https://earvincapagcuan.github.io/portfolio/" uk-icon="icon:github; ratio:2"></a></li>
				</div>
			</ul>
		</div>
		<div class="uk-text-center uk-margin-auto">
			<h3>The company</h3>
			<ul class="uk-list">
				<li><a href="#modal-disc" uk-toggle>Disclaimer</a></li>
			</ul>
		</div>
	</div>
	<p class="uk-text-center">Copyright &copy; 2018 Sale</p>
</footer>

<div id="modal-disc" uk-modal>
	<div class="uk-modal-dialog uk-modal-body uk-margin-auto">
		<h3>Disclaimer</h3>
		<p>All the information on this website - StrangeThings - is published in good faith and for educational purposes only. StrangeThings does not make any warranties about the completeness, reliability and accuracy of this information. The images found in this website does not belong to the developer, credits are to the respective owners. Any action you take upon the information you find on this website (StrangeThings), is strictly at your own risk. StrangeThings will not be liable for any losses and/or damages in connection with the use of our website.</p>
		<p>Please be also aware that when you leave our website, other sites may have different privacy policies and terms which are beyond our control. Please be sure to check the Privacy Policies of these sites as well as their "Terms of Service" before engaging in any business or uploading any information.</p>
		<h4>Consent</h4>
		<p>By using our website, you hereby consent to our disclaimer and agree to its terms.</p>
	</div>
</div>

<script type="text/javascript" src="../assets/js/script.js"></script>
<script type="text/javascript" src="../assets/js/jquery.countdown.js"></script>
<script type="text/javascript" src="../assets/js/jquery.fittext.js"></script>
<script type="text/javascript" src="../assets/js/easyzoom.js"></script>
<?php
$page = "admin";
require_once "../partials/template.php";

function get_page_content(){
	global $conn;
	$id = $_SESSION['user']['id'];
	$userQ = "SELECT * FROM users WHERE id = $id";
	$result = mysqli_query($conn, $userQ);
	$rows = mysqli_fetch_assoc($result);
?>
	<div class="uk-container-expand uk-padding-remove uk-margin-remove">
		<ul class="uk-breadcrumb uk-width-1-1@m uk-background-muted uk-margin-remove uk-padding-small">
			<li><a href="./admin-page.php">Accounts</a></li>
			<li><span>Update Account Information</span></li>
		</ul>
	</div>
	<div class="uk-container uk-padding-small">
	<form class="uk-form uk-width-2-3@m uk-margin-auto uk-margin-top">
		<fieldset class="uk-fieldset">
			<div class="uk-flex uk-child-width-1-3@m uk-margin">
				<span>First name: <?php echo $rows['firstname']; ?></span>
				<span>Last name: <?php echo $rows['lastname']; ?></span>
			</div>

			<legend class="uk-legend">Update account information</legend>

			<label class="uk-form-label">Street: </label>
			<input type="text" id="street" class="uk-input" name="street" placeholder="<?php echo $rows['street']; ?>"></input>

			<label class="uk-form-label">City: </label>
			<input type="text" id="city" class="uk-input" name="city" placeholder="<?php echo $rows['city']; ?>"></input>

			<label class="uk-form-label">Country: </label>
			<input type="text" id="country" class="uk-input" name="country" placeholder="<?php echo $rows['country']; ?>"></input>

			<label class="uk-form-label">Update email address</label>
			<input type="email" id="email" class="uk-input" name="email" placeholder="<?php echo $rows['email']; ?>"></input>
		</fieldset>
		<div class="uk-margin uk-text-center">
			<button type="button" class="uk-button" id="update-profile">Update information</button>
		</div>
	</form>
	</div>
	</div>
</div>

<?php } ?>
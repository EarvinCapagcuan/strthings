<?php
require_once "../partials/template.php";

function get_page_content(){
	global $conn; 
	$userQ = 'SELECT * FROM users WHERE level = 2 ';
	$userL = mysqli_query($conn, $userQ);
	?>

	<div class="uk-container uk-padding-small">
		<table class="uk-table uk-table-striped uk-table-divider uk-table-hover">
			<thead class="uk-background-secondary">
				<tr>
					<th>Name</th>
					<th>Email</th>
					<th>Username</th>
					<th>Bid History</th>
				</tr>
			</thead>
			<tbody>
				<?php
				foreach ($userL as $key => $users) {
					$userId = $users['id'];
					?>
				<tr> 
					<td><?php echo $users['firstname']." ".$users['lastname']; ?></td>
					<td><?php echo $users['email']; ?></td>
					<td><?php echo $users['username']; ?></td>
					<td><?php 
					$get_users_query = "SELECT * FROM bids bi JOIN users us ON (bi.user_id = us.id) WHERE us.id = $userId" ;
					var_dump($user_list = mysqli_query($conn, $get_users_query));
					foreach($user_list as $key => $indiv_user) { 
						if($indiv_user > 0){
							echo $indiv_user;
						}else{
							echo 0;
						}
					}
						?>
					</td>
				</tr>
				<?php } ?>
			</tbody>
		</table>
	</div>
<?php
}
?>
<?php
require_once "../partials/template.php";

function get_page_content(){
	global $conn;
	$id = $_SESSION['user']['id']; ?>

	<div class="uk-container">
	<h3 class="uk-heading-line"><span>Tracked items</span></h3>
		<div class="uk-margin-auto" uk-grid>
		<?php
		$items = "SELECT * FROM items it JOIN followed_items fi on fi.item_id = it.id WHERE fi.user_id = $id LIMIT 10";
		$result = mysqli_query($conn, $items); ?>

		<table class="uk-table uk-table-striped uk-table-divider uk-table-hover" border>
			<thead class="uk-background-secondary">
				<tr>
					<th>Item Name</th>
					<th>Current Highest Bid</th>
					<th>Actions</th>
				</tr>
			</thead>
			<tbody>
				<?php if($result){
					foreach ($result as $key => $value) {
						echo "<tr>
						<td>".$value['name']."</td>
						<td>".$value['highest_bid']."</td>
						<td class='uk-button-group uk-child-width-1-2 uk-width-1-1'>
							<button class='uk-button' id='remove-item' data-id=".$value['item_id'].">Remove</button>
							<button class='uk-button uk-button-secondary' id='bid'>Bid</button>
						</td>
					</tr>";
					}
				}else{
					echo die(mysqli_error($conn));
				} ?>
			</tbody>
		</table>
	</div>
	</div>

<?php } ?>
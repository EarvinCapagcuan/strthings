<?php
?>
<div class="uk-modal-header">
	<h3>change your password</h3>
</div>
<div class="uk-modal-body">
	<form class="uk-form uk-form-horizontal" id="password-change">
		<label class="uk-form-label" for="old-password">Old password</label>
		<div class="uk-form-controls uk-margin">
			<input type="text" class="uk-input" id="old_password" name="old_password" placeholder="Type your old password">
		</div>
		<label class="uk-form-label" for="new-password">New password</label>
		<div class="uk-form-controls uk-margin">
			<input type="password" class="uk-input" id="new_password" name="new_password" placeholder="Type the new password" required="">
		</div>
		<label class="uk-form-label" for="new-password2">Confirm new password</label>
		<div class="uk-form-controls uk-margin">
			<input type="password" class="uk-input" id="new_password2" name="new_password2" placeholder="Re-type new password">
		</div>
		<div id="error"></div>
	</div>
	<div class="uk-modal-footer uk-text-center">
		<div class="uk-button-group uk-width-1-1">
			<button type="button" id="change-button" class="uk-button uk-button-secondary uk-width-2-3" >Change password</button>
			<button type="button" class="uk-button uk-button-default uk-width-1-3 uk-modal-close">Cancel</button>
		</div>
	</div>
</form>
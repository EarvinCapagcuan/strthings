<?php
require_once "../partials/template.php";

function get_page_content(){
	global $conn;
	$itemId = $_GET['id'];
	$cat = $_GET['category_id'];
	$categoryNameQ = "SELECT cat.name FROM categories cat JOIN items it ON cat.id = it.category_id WHERE it.category_id = $cat ";
	$resultName = mysqli_query($conn, $categoryNameQ);
	$categoryName = mysqli_fetch_assoc($resultName);

	$itemsQ = "SELECT * FROM items where id = '$itemId' ";
	$getItem = mysqli_query($conn, $itemsQ);
	$result = mysqli_fetch_assoc($getItem);

	if(isset($_SESSION['user'])) {
		$user = $_SESSION['user']['id'];
		$bidCheckQ = "SELECT * FROM bids where item_id = $itemId AND user_id = $user AND bid_status = 3 ORDER BY bid_amt DESC LIMIT 1";
		$bidCheck = mysqli_query($conn, $bidCheckQ);
		$yourBid = mysqli_fetch_assoc($bidCheck);

		} ?>
		<div class="uk-grid uk-container uk-padding uk-padding-remove-horizontal uk-margin-auto" uk-grid>
			<div class="uk-width-2-3@m uk-width-1-2@s uk-flex-between@m">
				<h3 class="uk-head"><?php echo $result['name']; ?></h3><br>
				<div uk-grid class="uk-margin-auto uk-flex-center">
					<div class="uk-width-2-3@m uk-width-1-2@s uk-flex uk-flex-column">
						<img class="zoom_01" src='<?php echo $result['image_path']; ?>'/>
						<div class="uk-margin-remove-right">
							<span>category:</span>
							<span><a href="./categories.php?category_id=<?php echo $cat; ?>"><em><?php echo $categoryName['name']; ?></em></a></span>
						</div>
					</div>
					<div class="uk-width-1-3@m uk-width-1-2@s">
						<div class="uk-flex uk-flex-column">	
							<span>Initial bid is <?php echo $result['initial_bid'];?></span><br>	
							<span>Number of bids <?php echo $result['bid_count'];?></span><br>
							<span>Current bid is at &#8369;<?php echo $result['highest_bid'];?></span>
							<p><em><?php echo $result['description']; ?></em></p>
							<span class="uk-badge">Status: <?php echo ($result['item_status']==3 ? "Expired" : "Ongoing") ?></span><br>
							<span>Bidding end date is in <i class="clock"></i></span>
						</div>

					</div>
					<div class="uk-width-expand@m uk-width-1-2@s uk-flex uk-flex-left">
						<?php 
						if(isset($_SESSION['user']) && $_SESSION['user']['level'] == 2) {
							if($result['item_status']==2 || $result['item_status']==3) { ?>
								<a href="#" class="uk-button uk-button-default uk-width-1-3@m uk-width-1-2@s uk-disabled uk-text-muted">Bidding now closed</a>
							<?php }elseif($_SESSION['user']['id'] == $yourBid['user_id']){ ?>
								<a href="./checkout.php?id=<?php echo $yourBid['id'] ?>" class="uk-button uk-button-default uk-width-1-4@m uk-width-1-2@s" id="checkout" data-id="<?php echo $result['id']; ?>">Checkout Now</a>
							<?php }elseif($result['item_status']==4 ){ ?>
								<input class="uk-input uk-width-1-2@m uk-width-1-2@s" type="number" placeholder="Your bid <?php echo $yourBid['bid_amt'];?>" id="bid_amount"></input>
								<button class="uk-button uk-width-1-4@m uk-width-1-2@s add-to-follow" id="add-to-followed" data-id="<?php echo $result['id']; ?>">Watch item</button>
								<button class="uk-button uk-width-1-4@m uk-width-1-2@s" id="bid-now" data-id="<?php echo $result['id']; ?>">Bid now</button>
							<?php }
							}elseif(isset($_SESSION['user']) && $_SESSION['user']['level'] == 1){ ?>
							<a href="./edit-item-form.php?id=<?php echo $itemId; ?>" class="uk-button uk-button-default uk-width-1-2@s">Edit bid information</a>
							<?php }else{ ?>
							<a href="#" uk-toggle="target:#login-page" class="uk-button uk-button-default uk-width-1-2@s">Log in to place bid</a>
						<?php }	?>
					</div>
				</div>
			</div>
			<div class="uk-width-1-4@m uk-width-1-2@s uk-align-right">
				<h4>Other Items you may like</h4>
				<?php
				$itemsQ = "SELECT * FROM items WHERE id != $itemId AND category_id = $cat AND item_status = 4 ORDER BY bid_count LIMIT 3";
				$itemsL = mysqli_query($conn, $itemsQ);
				
				foreach ($itemsL as $key => $value) { ?>
					<div class="uk-card uk-card-hover uk-padding-small">
						<a href="./item-view.php?id=<?php echo $value['id']."&category_id=".$value['category_id'] ?>" class="uk-link-reset">
							<img class="card-img" src="<?php echo $value['image_path'] ?>">
							<span><?php echo $value['name']; ?></span><br>
							<span>Current Bid &#8369;<?php echo $value['highest_bid']; ?></span>
						</a>
					</div>
				<?php }	?>
			</div>
		</div>
		<div class="container">
			<div uk-gird class="uk-margin-auto uk-width-1-2@m uk-width-1-2@s">
				<h2 class="uk-heading uk-text-center">check other categories</h2>
				<div class="uk-flex uk-flex-around uk-child-width-2-3@m uk-child-width-1-2@s">
					<?php 
					$categoryQ = "SELECT * FROM categories ";
					$result = mysqli_query($conn, $categoryQ);
					foreach ($result as $key => $value) {
						if($value['name'] == $categoryName['name']){
							echo "<a href='#' class='uk-disabled uk-text-center uk-text-muted'>".$value['name']."</a>";
						}else{
							echo "<a href='./categories.php?category_id=".$value['id']."' class='uk-link-text uk-text-center'>".$value['name']."</a>";
						}
					}?>
				</div>
			</div>

		</div>

 <?php } ?>
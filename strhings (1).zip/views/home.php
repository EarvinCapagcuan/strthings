<?php require_once "../partials/template.php";
function get_page_content(){ 
	global $conn; ?>
	<div class="uk-container">
		<div class="uk-position-relative uk-visible-toggle uk-light" uk-slideshow="animation: push; min-height: 200; max-height: 240; autoplay: true; autoplay-interval: 3000">
			<ul class="uk-slideshow-items">
				<li>
					<div class="uk-position-cover" uk-slideshow-parallax="scale: 1.2,1.2,1">
						<img src="../assets/images/home.jpg" alt="" uk-cover>
					</div>
					<div class="uk-position-cover" uk-slideshow-parallax="opacity: 0,0,0.2; backgroundColor: #000,#000"></div>
					<div class="uk-overlay uk-overlay-primary uk-position-bottom-right uk-position-small uk-text-right">
						<div uk-slideshow-parallax="scale: 1,1,0.8">
							<h2 uk-slideshow-parallax="x: 200,0,0">Find unusual items</h2>
							<p uk-slideshow-parallax="x: 400,0,0;"> <a href="./register.php">Sign up now</a> and gain access to all things peculiar.</p>
						</div>
					</div>
				</li>
				<li>
					<div class="uk-position-cover" uk-slideshow-parallax="scale: 1.2,1.2,1">
						<img src="../assets/images/home2.jpg" alt="" uk-cover>
					</div>
					<div class="uk-position-cover" uk-slideshow-parallax="opacity: 0,0,0.2; backgroundColor: #000,#000"></div>
					<div class="uk-overlay uk-overlay-primary uk-position-top-left uk-position-small uk-text-left">
						<div uk-slideshow-parallax="scale: 1,1,0.8">
							<h2 uk-slideshow-parallax="x: 200,0,0">Make your friends cringe</h2>
							<p uk-slideshow-parallax="x: 400,0,0;">Want a statue that will haunt anyone who dare set foot on your garden? Take a look at the <a href="./categories.php">gallery</a> and place your bid.</p>
						</div>
					</div>
				</li>
								<li>
					<div class="uk-position-cover" uk-slideshow-parallax="scale: 1.2,1.2,1">
						<img src="../assets/images/human-lamp.jpg" alt="" uk-cover>
					</div>
					<div class="uk-position-cover" uk-slideshow-parallax="opacity: 0,0,0.2; backgroundColor: #000,#000"></div>
					<div class="uk-overlay uk-overlay-primary uk-position-center uk-position-small uk-text-left">
						<div uk-slideshow-parallax="scale: 1,1,0.8">
							<h2 uk-slideshow-parallax="x: 200,0,0">Special Event!</h2>
							<p uk-slideshow-parallax="x: 400,0,0;">We are giving everyone <strong>MORE</strong> time to bid. Instead of the traditional individual end date per item.</p>
							<p>You have <strong><span class="clock"></span></strong> to bid!</p>
						</div>
					</div>
				</li>
			</ul>
			<a class="uk-position-center-left uk-position-small uk-hidden-hover" href="#" uk-slidenav-previous uk-slideshow-item="previous"></a>
			<a class="uk-position-center-right uk-position-small uk-hidden-hover" href="#" uk-slidenav-next uk-slideshow-item="next"></a>
		</div>
	</div>

	<div class="uk-container uk-margin-bottom uk-padding">
		<h2 class="uk-text-center uk-heading-line"><span>Make your <small><em>(normie)</em></small> visitors cringe</span></h2>
		<div class="uk-child-width-1-3@m uk-child-width-1-1@s uk-margin" uk-grid>
			<p>Sick of that plain china vase on your table that your mother-in-law gave you for your wedding?</p>
			<p>You just want to be weird and different? Oppose the norm? Or are you thinking of starting a cult?</p>
			<p>Unique everything. We have a wide selection of one-of-a-kind items, so you can find whatever you need (or really, really want).</p>
		</div>
	</div>

	<div class="uk-container uk-text-center">
		<h2 class="uk-heading">Select a Category</h2>
		<div class="uk-margin-auto uk-flex uk-flex-around" uk-grid>
			<?php 
			$categoryQ = "SELECT * FROM categories ";
			$result = mysqli_query($conn, $categoryQ);
			foreach ($result as $key => $value) {
				echo "<a href='./categories.php?category_id=".$value['id']."' class='uk-link-text uk-padding-small'>".$value['name']."</a>";
			} ?>
		</div>
	</div>
	<div class="uk-container">
		<hr>
		<div id="countdown" class="uk-text-center uk-padding-medium uk-background-muted">
			<h3 class="uk-heading-hero clock"></h3>
			<h4>Limited Free Bid Event</h4>
		</div>
	</div>

	<div class="uk-container">
		<h2 class="uk-heading-line"><span>Top bids now</span></h2>
		<p>Here is a list of the current top bids based on the number of user bids.</p>
		<div class="uk-margin-auto" uk-grid>
			<?php
			$listQ1 = "SELECT * FROM items ORDER BY bid_count DESC LIMIT 5";
			$result1 = mysqli_query($conn, $listQ1);
			foreach ($result1 as $key => $rows1) { ?>
				<div class="uk-width-1-5@m uk-width-1-5@s uk-padding-small">
					<a href="./item-view.php?id=<?php echo $rows1['id']."&category_id=".$rows1['category_id'] ?>" class="uk-link-reset">
					<div class="uk-card uk-card-small">
						<div class="uk-background-cover uk-height-medium uk-visible-toggle uk-animation-toggle" data-src="<?php echo $rows1['image_path'] ?>" uk-img>
							<div class="uk-card-header">
							<h5 class="uk-card-title uk-overlay-primary uk-text-truncate uk-text-lead uk-text-center"><?php echo $rows1['name']; ?></h5>
							</div>
							<div class="uk-invisible-hover uk-overlay-primary uk-position-bottom uk-position-small uk-animation-fade uk-padding-remove">
								<div class="uk-card-body uk-text-meta">
									<p>Highest bid <?php echo $rows1['highest_bid']; ?></p>
									<p>Bid Count <?php echo $rows1['bid_count']; ?></p>
								</div>
							</div>
						</div>
					</div>
					</a>
				</div>
			<?php } ?>
		</div>
	</div>

<?php } ?>
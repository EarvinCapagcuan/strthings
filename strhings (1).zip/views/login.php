<?php
if(!isset($_SESSION['user'])){
	global $conn; ?>
<form class="uk-form-horizontal uk-width-1-1 uk-margin-auto">
	<h2 class="uk-heading uk-text-center">Log In</h2>
	<label class="uk-form-label" for="username">Username</label>
	<input type="text" class="uk-input" name="username" id="username" placeholder="Enter Username"></input>	
	<span class="validation"></span>
	<label class="uk-form-label" for="password">Password</label>
	<input type="password" class="uk-input" name="password" id="password" placeholder="Enter password"></input>
	<button type="button" id="login" class="uk-button uk-width-1-1 uk-margin">Log In</button>
</form>
<?php }else{
	echo "logged in"; ?>	
<?php } ?>
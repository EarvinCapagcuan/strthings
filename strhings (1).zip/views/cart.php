<?php if(isset($_SESSION['user']) && $_SESSION['user']['level'] == 2){ ?>
<h3 class="uk-heading-line"><span>Your Outstanding Bids</span></h3>
<div class="uk-container">
	<table class="uk-table uk-table-striped" id="cart-items">
		<thead class="uk-background-secondary">
			<tr>
				<th>Item name</th>
				<th>Your bid</th>
				<th>Bid Status</th>
				<th class="uk-text-center">Actions</th>
			</tr>
		</thead>
		<tbody>
			<?php
				$user_id = $_SESSION['user']['id'];
				$selectQ = "SELECT * FROM bids WHERE user_id = $user_id ";
				$select = mysqli_query($conn, $selectQ);
				
				if($select){
					foreach ($select as $key => $value) {
							$x = $value['item_id'];
							$categoryIdQ = "SELECT * FROM items WHERE id = $x";
							$categoryId = mysqli_query($conn, $categoryIdQ);
							$result = mysqli_fetch_assoc($categoryId);
							$y = $result['category_id'];
							$z = $result['name']; 

							$w = $value['bid_status'];
							$statusQ = "SELECT status_name FROM statuses WHERE id = $w ";
							$status = mysqli_query($conn, $statusQ);
							$resultStatus = mysqli_fetch_assoc($status); ?>
							<tr>
								<td>
									<?php echo $z;?></a>
								</td>
								<td>
									<?php echo $value['bid_amt']; ?>
								</td>
								<td>
									<?php echo $resultStatus['status_name'];?>
								</td>
								<td class="uk-text-center"> 
								<?php
									if($w == 4){ ?>
									<a class="uk-button" href="./item-view.php?id=<?php echo $x."&category_id=".$y ?>" class="uk-button">Go to item</a>
								<?php }elseif($w == 3) { ?>
									<a class="uk-button uk-muted" href="./item-view.php?id=<?php echo $x."&category_id=".$y ?>" class="uk-button">Check Result</a><?php
									} ?>
								</td>
							</tr>

				<?php	}
				}else{
					echo mysqli_error($conn);
				}
			?>
		</tbody>
	</table>
</div>
<?php
}else{ ?>
	<!-- 	<script type="text/javascript">
			window.location.href="./lost.php";	
		</script>	 -->
<?php }
 ?>

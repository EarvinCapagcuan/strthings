<div class="uk-container-expand">
	<div class="uk-preserve-color">
		<div uk-sticky="animation: uk-animation-slide-top; sel-target: .uk-navbar-container; cls-active: uk-navbar-sticky; cls-inactive: uk-navbar-transparent; top: 200">
			<nav class="uk-navbar-container uk-background-secondary" uk-navbar>
				<a href="<?php if(isset($_SESSION['user']) && $_SESSION['user']['level']==1){ echo"./admin-page.php"; }else{ echo "./home.php"; } ?>" class="uk-logo uk-navbar-item">Strange Things</a>
				<div class="uk-navbar-right">
					<ul class="uk-navbar-nav uk-visible@s navigation">
					<?php if(isset($_SESSION['user']) && $_SESSION['user']['level']==1) { ?>
						<li><a class="<?php echo $page == "categories" ? "uk-background-default" : "" ?>" href="./categories.php">Bids</a>
							<div uk-dropdown class="uk-background-secondary uk-margin-remove uk-width-expand">
								<ul class="uk-nav uk-dropdown-nav">
									<li><a href="./add-item.php">Open a Bid</a></li>
									<li><a href="./posted-items.php">Modify a Bid</a></li>
									<li><a href="./close-bid.php">Close a bid</a></li>
								</ul>
							</div>
						</li>
						<li><a class="<?php echo ($page == "admin")?"uk-background-default" : ""; ?>" href="./designate-users.php">Accounts</a>
							<div uk-dropdown class="uk-background-secondary uk-margin-remove uk-width-expand">
								<ul class="uk-nav uk-dropdown-nav">
									<li><a href="./update-profile.php">Update Your Information</a></li>
									<li><a href="./designate-users.php">Designate Another Admin</a></li>
								</ul>
							</div>
						</li>
						<li><a class="<?php if($page=="account"){echo "uk-background-default uk-text-secondary";} ?>" href="./admin-page.php"><?php echo $_SESSION['user']['name']; ?></a></li>
						<li><a href="../controllers/logout.php">Log out</a></li>
					<?php } elseif(isset($_SESSION['user']) && $_SESSION['user']['level']==2) { ?>
						<li><a uk-toggle="target:#bid-items" href="#" id="cart-icon">Your bids</a></li>
						<li><a class="<?php if($page=="categories"){echo "uk-background-default";} ?>" href="./categories.php">Catalog</a></li>
						<li><a class="<?php if($page=="account"){echo "uk-background-default";} ?>" href="./user-profile.php"><?php echo $_SESSION['user']['name']; ?></a></li>
						<li><a href="../controllers/logout.php">Log out</a></li>
					<?php }else{ ?>
						<li><a class="<?php if($page=="categories"){echo "uk-background-default";} ?>" href="./categories.php">Catalog</a></li>
						<li><a class="<?php if($page=="register"){echo "uk-background-default";} ?>"href="./register.php">Register</a></li>
						<li><a href="#" uk-toggle="target:#login-page">Login</a></li>
					<?php } ?>
					</ul>
				</div>
				<button class="uk-button uk-hidden@s" type="button" uk-toggle="target: .off-canvas-menu"><span uk-icon="menu"></span></button>	
			</nav>
		</div>
	</div>
</div>

<!-- cart -->
<div id="bid-items" class="uk-modal  uk-modal-container" uk-modal>
	<div class="uk-modal-dialog uk-modal-body" uk-overflow-auto>
		<?php include "./cart.php"; ?>
	</div>
</div>

<!-- off-canvas login-->
<div id="login-page" uk-offcanvas=" mode: push; overlay:true; flip:true;">
	<div class="uk-offcanvas-bar">
		<button class="uk-offcanvas-close" type="button" uk-close></button>
		<?php include "./login.php"; ?>
	</div>
</div>

<!-- off canvas nav when in mobile -->
<div class="off-canvas-menu uk-hidden@m" uk-offcanvas="overlay: true">
	<div class="uk-offcanvas-bar uk-flex uk-flex-column uk-width-1-2">
		<ul class="uk-nav uk-nav-default uk-nav-left" uk-nav>
			<li class="uk-nav-header"><a href="<?php if(isset($_SESSION['user']) && $_SESSION['user']['level']==1){ echo"./admin-page.php"; }else{ echo "./catalog.php"; } ?>">ST</a></li>
			<hr>
				<ul class="uk-nav-sub">
					<?php if(isset($_SESSION['user']) && $_SESSION['user']['level']==1) { ?>
						<li class="uk-parent"><a href="./categories.php">Bids</a>
							<ul class="uk-nav-sub">
								<li><a href="./add-item.php">Open a Bid</a></li>
								<li><a href="./posted-items.php">Modify a Bid</a></li>
								<li><a href="./close-bid.php">Close a bid</a></li>
							</ul>
						</li>
						<li class="uk-parent"><a href="#">Accounts</a>
							<ul class="uk-nav-sub">
								<li><a href="./update-profile.php">Your Information</a></li>
								<li><a href="./designate-users.php">Designate Admin</a></li>
							</ul>
						</li>
						<li><a href="./admin-page.php" ><?php echo $_SESSION['user']['name']; ?></a>
						</li>
						<li><a href="../controllers/logout.php">Log out</a></li>
					<?php } elseif(isset($_SESSION['user']) && $_SESSION['user']['level']==2) { ?>
						<li><a uk-toggle="target:#bid-items" href="#" id="cart-icon">Your bids</a></li>
						<li><a  href="./categories.php">Catalog</a></li>
						<li><a href="./user-profile.php"><?php echo $_SESSION['user']['name']; ?></a></li>
						<li><a href="../controllers/logout.php">Log out</a></li>
					<?php }else{ ?>
						<li><a href="./categories.php">Catalog</a></li>
						<li><a href="./register.php">Register</a></li>
						<li><a href="#" uk-toggle="target:#login-page">Login</a></li>
					<?php } ?>
		</ul>
	</div>
</div>

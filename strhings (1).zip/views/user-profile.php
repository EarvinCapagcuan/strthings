<?php
$page = "account";
require_once "../partials/template.php";

function get_page_content(){
	global $conn;
	if(isset($_SESSION['user']) && $_SESSION['user']['level']==2){ 
		$id = $_SESSION['user']['id'];
		$userQ = "SELECT * FROM users where id = $id;";
		$userInfo = mysqli_query($conn, $userQ);
		$rows = mysqli_fetch_assoc($userInfo);
		$address = $rows['street'].", ".$rows['city']." ".$rows['country']; 
		$items = "SELECT * FROM items it JOIN followed_items fi on fi.item_id = it.id WHERE fi.user_id = $id LIMIT 10";
		$result = mysqli_query($conn, $items); 
		$rowsI = mysqli_num_rows($result);
		$bidCountQ = "SELECT * FROM bids WHERE user_id = $id ";
		$bidCountL = mysqli_query($conn, $bidCountQ);
		$bidCount = mysqli_num_rows($bidCountL);
		?>

		<div class="uk-container">
			<div class="uk-align-center uk-child-width-1-3@m uk-child-width-1-1@s uk-flex" uk-grid>
			<section class="uk-section">
				<h3>Profile</h3>
				<p>Full name: <?php echo $rows['firstname']." ".$rows['lastname']; ?></p>
				<p>Email: <?php echo $rows['email']; ?></p>
				<p>Address: <?php echo $address; ?></p>
			</section>
			<section class="uk-section">
				<h3>Stats</h3>
				<p>Tracked items: <a href="#tracked"><?php echo $rowsI; ?></a></p>
				<p>Bids: <a href="#cart"><?php echo $bidCount; ?></a></p>
			</section>
			<section class="uk-section">
				<h3>Account</h3>
				<ul class="uk-list">
					<li><a class="uk-button uk-button-default" href="./update-profile.php">Update information</a></li>
					<li><a class="uk-button uk-button-default" uk-toggle="target:#change-password" href="#">Change password</a></li>
				</ul>
			</section>
			</div>
		</div>

		<div class="uk-container">
			<h3 class="uk-heading-line" id="tracked"><span>Tracked items</span></h3>
			<div class="uk-margin-auto uk-flex" uk-grid>
				<table class="uk-table uk-table-striped uk-table-divider uk-table-hover">
					<thead class="uk-background-secondary">
						<tr>
							<th>Item Name</th>
							<th>Current Highest Bid</th>
							<th class="uk-text-center">Actions</th>
						</tr>
					</thead>
					<tfoot>
						<tr>
						<?php
							if($rows>0){ ?>
								<td colspan="3" class="uk-text-center"><a class="uk-button uk-button-default uk-width-2-3@m uk-width-1-2@s" href="./tracked-items.php">All Tracked Items</a></td>
						<?php }else{ ?>
								<td colspan="3" class=" uk-text-center"><a class="uk-button uk-button-default uk-width-2-3@m uk-width-1-2@s uk-disabled uk-text-muted" href="./tracked-items.php">There are no Tracked Items</a></td>
						<?php } ?>
						</tr>
					</tfoot>
					<tbody>
						<?php if($result){
							foreach ($result as $key => $value) {
								echo "<tr>
										<td>".$value['name']."</td>
										<td>".$value['highest_bid']."</td>
										<td class='uk-button-group uk-child-width-1-2 uk-width-1-1'>
											<button class='uk-button' id='remove-item' data-id=".$value['item_id'].">Remove</button>
											<a class='uk-button uk-button-secondary' id='bid' href='./item-view.php?id=".$value['id']."&category_id=".$value['category_id']."'>Bid</a>
										</td>
									</tr>";
							}
						}else{
							echo die(mysqli_error($conn));
						} ?>
					</tbody>
				</table>
			</div>
		</div>
		<div id="cart"></div>
		<div class="uk-container uk-padding-large">
			<?php include "./cart.php"; ?>
		</div>

<div id="change-password" uk-modal>
	<div class="uk-modal-dialog">
	<?php include "./change-password.php"; ?>
	</div>
</div>

<?php }else{ ?>
			<script type="text/javascript">
			window.location.href="./lost.php";	
		</script>	
<?php }
}
?>
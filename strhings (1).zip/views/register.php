<?php
$page = "register";
require_once "../partials/template.php";

function get_page_content(){
	global $conn; ?>
	<div class="uk-container uk-container-expand">
		<form class="uk-form-horizontal uk-width-1-1@s uk-width-1-2@m uk-margin-auto" id="reg-form">
			<h2 class="uk-heading uk-text-center">Register</h2>
			<div class="uk-column-1-2 uk-margin-bottom">
				<div>
					<label class="uk-form-label" for="firstname">First Name:</label>
					<input type="text" class="uk-input" id="firstname" name="firstname" placeholder="First name">
					<span class="validation"></span>
				</div>
				<div>
					<label class="uk-form-label" for="lastname">Last Name:</label>
					<input type="text" class="uk-input" id="lastname" name="lastname" placeholder="Last name">
					<span class="validation"></span>
				</div>
			</div>
			<label class="uk-form-label" for="uname">Username:</label>
			<div class="uk-form-controls uk-margin-small">
				<input type="text" class="uk-input uk-width-1-1" id="uname" name="uname" placeholder="Username">
			</div>
			<span class="validation"></span>
			<label class="uk-form-label" for="pass">Password:</label>
			<div class="uk-form-controls">
				<input type="password" class="uk-input uk-width-1-1" id="pass" name="pass" placeholder="Password">
			</div>
			<span class="validation"></span>
			<label class="uk-form-label" for="confirm-password">Re-type Password:</label>
			<div class="uk-form-controls">
				<input type="password" class="uk-input uk-width-1-1" id="confirm-password" name="confirm-password" placeholder="Re-type password"></input>
				<span class="validation"></span>
			</div>
			<label class="uk-form-label" for="email">Email:</label>
			<div class="uk-form-controls">
				<input type="email" class="uk-input uk-width-1-1" id="email" name="email" placeholder="Valid email address">
				<span class="validation"></span>
			</div>
			<div class=" uk-column-1-2 uk-margin-medium-top uk-column-divider">
				<fieldset class="uk-fieldset uk-margin-medium">
					<legend class="uk-legend">Address</legend>
					<label class="uk-form-label" for="street">Street</label>
					<input type="text" class="uk-input" name="street" id="street" placeholder="Street address">
					<span class="validation"></span>
					<label class="uk-form-label" for="city">City or State</label>
					<input type="text" class="uk-input" name="city" id="city" placeholder="City/State">
					<span class="validation"></span>
					<label class="uk-form-label" for="country">Country</label>
					<input type="text" class="uk-input" name="country" id="country" placeholder="Country">
					<span class="validation"></span>
				</fieldset>
				<fieldset class="uk-fieldset uk-margin-medium">
					<legend class="uk-legend">Other info</legend>
					<div class="uk-grid-medium uk-grid">
						<label class="uk-form-label">Gender</label>
						<label><input class="uk-radio gender" type="radio" name="gender" value="male"> Male</label>
						<label><input class="uk-radio gender" type="radio" name="gender" value="female"> Female</label>
					</div>
					<label class="uk-form-label" for="birthday">Birthday</label>
					<input type="date" class="uk-input" name="birthday" id="birthday">
				</fieldset>
			</div>
			<div class="uk-button-group uk-width-1-1 uk-margin-medium">
				<button type="button" class="uk-button uk-button-secondary uk-width-1-1" id="add_user">Register</button>
			</div>
		</form>
	</div>
	<?php } ?>
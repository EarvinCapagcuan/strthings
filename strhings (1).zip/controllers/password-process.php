<?php
	session_start();
	require_once "./connection.php";

	$id = $_SESSION['user']['id'];
	$current = sha1($_POST['old_password']);
	$password = $_POST['password'];
	$password2 = $_POST['password2'];

	$selectQ = "SELECT * FROM users WHERE password = '$current' ";
	$result = mysqli_query($conn, $selectQ);
	$rows = mysqli_num_rows($result);

	if($rows > 0){
		$rows2 = mysqli_fetch_assoc($result);
		$hashed = sha1($password); 
		if($rows2['password'] != $hashed){
			$changeQ = "UPDATE users SET password = '$hashed' WHERE id = '$id' "; 
			$result = mysqli_query($conn, $changeQ);

			if($result){
				echo 'success';
			}else{
				echo mysqli_error('something went wrong '.$conn);
			}
		}else{
			echo die('you cannot use the same password');
		}
	}else{
		echo die('incorrect old password');
	}
 ?>
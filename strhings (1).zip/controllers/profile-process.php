<?php
session_start();
require_once "./connection.php";

$street = $_POST['street'];
$city = $_POST['city'];
$country = $_POST['country'];
$email = $_POST['email'];
$id = $_SESSION['user']['id'];

$updateQ = "UPDATE users SET street = '$street', city = '$city', country = '$country', email = '$email' WHERE id = '$id'; ";
$result = mysqli_query($conn, $updateQ);

if($result){
	echo "success";
}else{
	die(mysqli_error($conn));
}
?>
<?php
session_start();
if(isset($_GET['sort'])){
	if($_GET['sort'] == "asc"){
		$_SESSION['sort'] = " ORDER BY initial_bid asc";
	}elseif($_GET['sort'] == "desc"){
		$_SESSION['sort'] = " ORDER BY initial_bid desc";
	}elseif($_GET['sort'] == "date"){
		$_SESSION['sort'] = " ORDER BY end_date";
	}elseif($_GET['sort'] == "count"){
		$_SESSION['sort'] = " ORDER BY bid_count";
	}elseif($_GET['sort'] == "status"){
		$_SESSION['sort'] = " ORDER BY item_status";
	}
}
header("Location: " . $_SERVER["HTTP_REFERER"]);

?>
<?php
session_start();

function getCartCount(){
	return count($_SESSION['cart']);
}
/*function getCartTotal(){
	$total = 0;
	foreach($_SESSION['cart'] as $id => $quantity){
		$total+=$_SESSION['cart'][$id];
	}
	return array_sum($_SESSION['cart']);
}*/
function updateQuantity(){
	$_SESSION['cart'][$id] -= $quantity;
}

$id = $_POST['id'];
$bid = $_POST['bid'];

if(!$bid == 0){
	if(isset($_SESSION['cart'][$id])){
		$_SESSION['cart'][$id] = $bid;
	}else{
		$_SESSION['cart'][$id] += $bid;
	}
}

/*clearing the cart*/
if(isset($_POST['response'])){
	unset($_SESSION['cart']);
}

?>
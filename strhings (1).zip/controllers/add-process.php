<?php
session_start();
require_once "./connection.php";

$valid_extensions = array('jpeg', 'jpg', 'png', 'gif', 'bmp'); // valid extensions
$path = '../assets/images/'; // upload directory
$name = $_POST['item'];
$desc = $_POST['desc'];
$i_bid = $_POST['initial_bid'];
$category = $_POST['category'];
$user_id = $_SESSION['user']['id'];

/*$data = array($path, $name, $desc, $i_bid, $category, $user_id);*/
if($_FILES['userImage'] && $name && $desc && $i_bid && $category) {
	$img = $_FILES['userImage']['name'];
	$tmp = $_FILES['userImage']['tmp_name'];
	$size = $_FILES['userImage']['size'];

// get uploaded file's extension
	$ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));

// can upload same image using rand function
	$final_image = rand(1000,1000000).$img;

// check's valid format
	if(in_array($ext, $valid_extensions)){ 
		$path = $path.strtolower($final_image); 
		if($size > 5000000){
			echo "Image too large.";
		}else{
			//run query
			$addQ = "INSERT INTO items (name, description, image_path, initial_bid, category_id, seller_id, item_status) VALUES ('$name', '$desc', '$path', $i_bid, $category, $user_id, 4)";
			$result = mysqli_query($conn, $addQ);
			if($result){
				move_uploaded_file($tmp, $path);
				echo "Upload successful.";
			} else {
				echo mysqli_error($conn);
			}
		}
	}
} else {
	echo mysqli_error($conn);
}
?>
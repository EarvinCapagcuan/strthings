<?php
session_start();
require_once "./connection.php";

if(isset($_SESSION['user']) && $_SESSION['user']['level']==1){
	$bidId = $_GET['id'];

	$bidQ = "SELECT * FROM bids WHERE id = $bidId ";
	$bidL = mysqli_query($conn, $bidQ);
	$bid = mysqli_fetch_assoc($bidL);
	$bidId = $bid['id'];
	$bidItem = $bid['item_id'];

	$winBidQ = "INSERT INTO bid_win (bid_id) VALUES ($bidId) ";
	$winBidL = mysqli_query($conn, $winBidQ);

	$updateStatusQ = "UPDATE items itm JOIN bids bid ON itm.id = bid.item_id SET itm.item_status = 3, bid.bid_status = 3 WHERE itm.id = $bidItem ";

	$updateStatusL = mysqli_query($conn, $updateStatusQ);

	if($winBidL && $updateStatusL){
		echo "success";
		header("Location:../views/close-bid.php");	
	}else{
		echo mysqli_error($conn);
	}
}
?>
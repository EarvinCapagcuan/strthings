<?php
session_start();
require_once "./connection.php";

$valid_extensions = array('jpeg', 'jpg', 'png', 'gif', 'bmp'); // valid extensions

$path = '../assets/images/'; // upload directory
$itemId = $_POST['itemId'];
$name = $_POST['item_name'];
$desc = $_POST['item_desc'];
$i_bid = $_POST['item_initial_bid'];
$category = $_POST['category'];
$user_id = $_SESSION['user']['id'];

if($_FILES['new_item_image'] /*&& $name && $desc && $i_bid && $category*/) {
	$img = $_FILES['new_item_image']['name'];
	$tmp = $_FILES['new_item_image']['tmp_name'];
	$size = $_FILES['new_item_image']['size'];
	// get uploaded file's extension
	$ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));

	if(!$img){
		$updateQ = "UPDATE items SET name = '$name', description = '$desc' , initial_bid = $i_bid, category_id = $category WHERE id = $itemId ";
		$result = mysqli_query($conn, $updateQ);
		if($result){
			move_uploaded_file($tmp, $path);
			echo "Upload successful.";
		} else {
			echo mysqli_error($conn);
		}
	}else{
		// can upload same image using rand function
		$final_image = rand(1000,1000000).$img;

		if(in_array($ext, $valid_extensions)){ 
			$path = $path.strtolower($final_image); 
			if($size > 5000000){
				echo "Image too large.";
			}else{
				$updateQ = "UPDATE items SET name = '$name', description = '$desc' , initial_bid = $i_bid, category_id = $category, image_path = '$path' WHERE id = $itemId ";
				$result = mysqli_query($conn, $updateQ);
				if($result){
					move_uploaded_file($tmp, $path);
					echo "Upload successful.";
				} else {
					echo mysqli_error($conn);
				}
			}
		}else{
			echo "this happened";
		}
	}
} else {
	echo "asdss";
}

?>
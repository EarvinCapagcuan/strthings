<?php
require_once "./connection.php";

	$fname =$_POST['firstname'];
	$lname =$_POST['lastname'];
	$uname =$_POST['uname'];
	$password = sha1($_POST['pass']);
	$email =$_POST['email'];
	$street =$_POST['street'];
	$city =$_POST['city'];
	$country =$_POST['country'];
	$gender =$_POST['gender'];
	$bday =$_POST['birthday'];

$unameCheckQ = "SELECT * FROM users WHERE username = '$uname'";
$result = mysqli_query($conn, $unameCheckQ);

if(mysqli_num_rows($result) > 0){
	echo "Username exists!";
}else{
	$addQ = "INSERT INTO users (firstname, lastname, username, password, email, street, city, country, gender, birthday) VALUES 
								('$fname','$lname','$uname','$password','$email','$street','$city','$country ','$gender','$bday')";
	$result = mysqli_query($conn, $addQ);
	echo die(mysqli_error($conn));
}
?>
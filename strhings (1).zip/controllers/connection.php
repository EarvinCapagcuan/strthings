<?php
	$host = "localhost";
	$username = "id7832112_strangethings";
	$password = "T1e2s3t4!";
	$db_name = "id7832112_strangethings";

	$conn = mysqli_connect($host, $username, $password, $db_name);

	if(!$conn){
		die("Connection Error: ".mysqli_error($conn));
	}
?>
<?php
session_start();
require_once "./connection.php";
require "../vendor/autoload.php";

use PayPal\Rest\ApiContext;
use PayPal\Auth\OAuthTokenCredential;
use PayPal\Api\Payer;
use PayPal\Api\Details;
use PayPal\Api\Item;
use PayPal\Api\ItemList;
use PayPal\Api\Amount;
use PayPal\Api\Transaction;
use PayPal\Api\RedirectUrls;
use PayPal\Api\Payment;

require "./paypal/start.php";
//import the necessary classes of phpmailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function generate_transaction_code(){
	$ref_num="";
	$source =['0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'];
	//we want to make a random 6 string long transaction code
	for($i=0; $i<6; $i++){
		$index =rand(0,15); //generates a random number from 0 to 15
		//append random character
		$ref_num=$ref_num .$source[$index];
	}
	$today=getdate(); //gets the datetime
	return $ref_num . "-".$today[0]; //today[0] is the second since unix epoch
}
//get all details of the order
$user_id=$_SESSION['user']['id'];
$status_id=1;
$payment_mode_id = $_POST['payment_mode'];
$address=$_POST['addressLine1'];
$trans_code=generate_transaction_code();
$_SESSION['trans_code']=$trans_code;	
$item_id = $_POST['itemId'];
$bid_id = $_POST['bidId'];

if ($payment_mode_id == 2){ //COD payment
	$trans_code = generate_transaction_code();
	$_SESSION['trans_code'] = $trans_code;

	$sql_query="INSERT INTO orders(user_id, transaction_code, status_id, payment_mode_id, item_id) VALUES ($user_id, '$trans_code', $status_id, $payment_mode_id, $item_id)";
	$result=mysqli_query($conn, $sql_query);

	$new_order_id= mysqli_insert_id($conn);
//populate the order_items
//SESSION cart is just an indexed array for quantities and each index corresponds to a specific item_id
	if($result){

		$getBidQ = "SELECT bid_amt FROM bids WHERE id = $bid_id ";
		$getBidL = mysqli_query($conn, $getBidQ);
		$getBid = mysqli_fetch_assoc($getBidL);

		-$sql= "INSERT INTO orders_items(order_id, bid_id, price) VALUES($new_order_id, $bid_id, ".$getBid['bid_amt'].");";
		$ord_item = mysqli_query($conn, $sql);
		if($ord_item){
			unset($_SESSION['cart']);
		}else{
			echo mysqli_error($conn);
		}
	}else{
		echo mysqli_error($conn);
	}

	$mail = new PHPMailer(true);
	$staff_email = 'PeculiarAuction@gmail.com';
	$customer_email =$_SESSION['user']['email'];
	$email_subject= "Peculiarity: Order confirmation";
	$email_body= "<h3>Reference Number: $trans_code</h3> <p>Ship to $address</p>";

//actual sending of email
	try {
	/*$mail->SMTPDebug = 4; */// Enables us to see detailed debug output
	$mail->isSMTP();// sets mailer to user SMTP to send
	$mail->Host= 'smtp.gmail.com';//uses gmail's smtp server
	$mail->SMTPAuth =true; //Enables SMTP authentication
	$mail->Username= $staff_email; //defines the email's username
	$mail->Password = "Test1234!";//defines email's password

	$mail->SMTPSecure ='tls';//allows for TLS encryption, we can also use ssl
	$mail->Port = 587;//port to cnnect

	//recipients
	$mail->setFrom($staff_email, "Peculiarity"); // Sets the sender's alias.
	$mail->addAddress($customer_email);

	//content
	$mail-> isHTML(true);//set emails format to HTML
	$mail->Subject = $email_subject;
	$mail->Body = $email_body;

	$mail->send();
	
} catch (Exception $e) {
	echo "Message couldn't be sent. Mailer Error".$mail->ErrorInfo;
}
//try catch: it performs a block of code and if it fails it catches the error message

//end send wmail
?>
<script type="text/javascript">
	window.location.href="../views/confirmation.php";
</script>
<?php
} else { //paypal payment
	$_SESSION['address'] = $_POST['addressLine1'];

	$payer = new Payer();
	$payer->setPaymentMethod('paypal'); 

	$getBidQ = "SELECT * FROM items WHERE id = $item_id";
	$getBid = mysqli_fetch_assoc(mysqli_query($conn, $getBidQ));
	extract($getBid);

	$payer = new Payer();
	$payer->setPaymentMethod("paypal");	

	$total = 0;
	 
	$item1 = new Item();
	$item1->setName($name)
	->setCurrency('PHP')
	->setQuantity(1)
	->setPrice($highest_bid);

	$items = array($item1);

	$itemList = new ItemList();
	$itemList->setItems($items);

	$amount = new Amount();
	$amount->setCurrency("PHP")
	->setTotal($highest_bid);

	$transaction = new Transaction();
	$transaction->setAmount($amount)
	->setItemList($itemList)
	->setDescription("Payment description")
	->setInvoiceNumber(uniqid());

	$redirectUrls = new RedirectUrls();
	$redirectUrls->setReturnUrl('http://localhost:8080/capstone2/app/controllers/pay.php?success=true')
	->setCancelUrl('http://localhost:8080/capstone2/app/controllers/pay.php?success=false');

	$payment = new Payment();
	$payment->setIntent("order")
	->setPayer($payer)
	->setRedirectUrls($redirectUrls)
	->setTransactions(array($transaction));

	try {
		$payment->create($paypal);
	}catch(PayPal\Exception\PayPalConnectionException $ex) {
	echo $payment;
    echo $ex->getCode(); // Prints the Error Code
    echo $ex->getData(); // Prints the detailed error message 
    die($ex);

} catch (Exception $ex) {
	die($ex);
}

$approvalUrl = $payment->getApprovalLink();

	header('location: '.$approvalUrl); 
}

?>
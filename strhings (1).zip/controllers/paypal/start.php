<?php
	$paypal =  new \PayPal\Rest\ApiContext(
		new \PayPal\Auth\OAuthTokenCredential(
		"AX186uebxSeVYF5Bl7eHqVGh_9Txmwd52V1R82xcbleywDuahktyqdUcGHwwH4fDnUPp2QqKBtAbgvfR",
		"EJhoy5CBWnwENQmA3BRuX2l1ywZWqyl4M_4i0m4MwBZdCFA_bDG9TG80oev1k11MEj-V94Jfij2gJkR8")
	);
?>
<?php
require_once "./connection.php";

$id = $_GET['id'];
$checkORderQ = "SELECT item_id FROM orders WHERE id = $id ";
$itemId = mysqli_fetch_assoc(mysqli_query($conn, $checkORderQ));
$complete_order_query = "UPDATE orders ord SET ord.status_id = 2 WHERE ord.id = $id; ";
mysqli_query($conn, $complete_order_query);
$setStatusQ = "UPDATE items SET item_status = 2 WHERE id = ".$itemId['item_id']." ";
$setStatusQ2 = "UPDATE bids SET bid_status = 2 WHERE item_id = ".$itemId['item_id']." ";
mysqli_query($conn, $setStatusQ);
mysqli_query($conn, $setStatusQ2);
header("Location: ../views/complete-order.php");
?>
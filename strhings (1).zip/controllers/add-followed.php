<?php
session_start();
require_once "./connection.php";

if(isset($_SESSION['user'])){

	$user_id = $_SESSION['user']['id'];

	if(isset($_POST['x'])){
		$x = $_POST['x'];
		foreach ($x as $key => $value) {
			$checkQ = "SELECT DISTINCT item_id FROM followed_items WHERE user_id = $user_id AND item_id = $value ";
			$result = mysqli_query($conn, $checkQ);
			$rows = mysqli_num_rows($result);
			if($rows > 0){
				$items[] = $value;
			}
		}
	echo json_encode($items);
	}
	if(isset($_POST['follow'])){
		$item_id = $_POST['id'];
		$checkQ = "SELECT * FROM followed_items WHERE user_id = $user_id AND item_id = $item_id ";

		$result = mysqli_query($conn, $checkQ);
		$rows = mysqli_num_rows($result);

		if($rows > 0){
			echo "do you want to unfollow this item?";
		}else{
			$itemQ = "INSERT INTO followed_items (user_id, item_id) VALUES ($user_id, $item_id) ";
			$result2 = mysqli_query($conn, $itemQ);
			if($result2){
				echo "Added to tracked items list.";
			}else{
				echo 'already';
			}
		}
	}elseif(isset($_POST['unfollow'])){
		$item_id = $_POST['id'];
		$itemD = "DELETE FROM followed_items WHERE user_id = $user_id AND item_id = $item_id ";
		echo $itemD;
		$result2 = mysqli_query($conn, $itemD);
		if ($result2) {
			echo mysqli_error($conn);
			echo "Unfollowed item ".$item_id;
		}
	}
}else{
	die(mysqli_error($conn));
}
?>
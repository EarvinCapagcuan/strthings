<?php
require_once "./connection.php";
$id = $_GET['id'];
$update_user_query = "SELECT level FROM users WHERE id = $id;";
$query_result = mysqli_query($conn, $update_user_query);
$user_role = mysqli_fetch_assoc($query_result);

if($user_role['level'] == 2) {
	$update_role_query = "UPDATE users SET level = 1 WHERE id = $id;";

} else {
	$update_role_query = "UPDATE users SET level = 2 WHERE id = $id;";
}

mysqli_query($conn, $update_role_query);
header("Location: ../views/designate-users.php");
?>
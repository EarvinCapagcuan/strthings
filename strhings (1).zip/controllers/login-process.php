<?php
session_start();
require_once "./connection.php";

$username = $_POST['username'];
$password = sha1($_POST['password']);

$loginQ = "SELECT * FROM users WHERE username = '$username'";
$result	= mysqli_query($conn, $loginQ);
$rows = mysqli_fetch_assoc($result);
if($rows){
	if($password == $rows['password']){
		if($rows['level'] == 1){
			$_SESSION["user"] = array('name' => $rows['username'],
								'id' => $rows['id'],
								'firstname' => $rows['firstname'],
								'lastname' => $rows['lasttname'],
								'email' => $rows['email'],
								'level' => $rows['level']
							);
			echo "admin";
		}else{
			$_SESSION["user"] = array('name' => $rows['username'],
								'id' => $rows['id'],
								'firstname' => $rows['firstname'],
								'lastname' => $rows['lasttname'],
								'email' => $rows['email'],
								'level' => $rows['level']
							);
		}
	}else{
		die("login_failed");
	}
}else{
	die("login_failed");
}
?>
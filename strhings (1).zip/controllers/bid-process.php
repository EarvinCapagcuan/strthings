<?php
session_start();
require_once "./connection.php";

$item = $_POST['id'];
$bid = $_POST['bid'];
$user = $_SESSION['user']['id'];

$selectQ = "SELECT * FROM items WHERE id = $item";
$select = mysqli_query($conn, $selectQ);
$result = mysqli_fetch_assoc($select);
$status = $result['item_status'];

if($result){
	$checkBidQ = "SELECT * FROM bids where user_id = $user AND item_id = $item ";
	$resultCheck = mysqli_query($conn, $checkBidQ);
	$rowsCheck = mysqli_fetch_assoc($resultCheck);

	if($rowsCheck){
		if($bid > $rowsCheck['bid_amt'] && $bid != $rowsCheck['bid_amt']){
			if($bid > $result['highest_bid'] && $bid != $result['highest_bid']) {
				$updateBidQ = "UPDATE bids SET bid_amt = $bid WHERE user_id = $user AND item_id = $item  ";
				$updateBid = mysqli_query($conn, $updateBidQ);
				$updateHighestQ = "UPDATE items SET highest_bid = $bid, bid_count = bid_count + 1 WHERE id = $item";
				$updateHighest = mysqli_query($conn, $updateHighestQ);
				echo 2;
			}else{
				echo 3;
			}
		}else{
			echo 4;
		}
	}else{
		if($bid > $result['initial_bid'] && $bid > $result['highest_bid']){
			$addBidQ = "INSERT INTO bids (user_id, item_id, bid_amt, bid_status) VALUES ($user, $item, $bid, $status)";
			$bidNow = mysqli_query($conn, $addBidQ);
			$updateHighestQ = "UPDATE items SET highest_bid = $bid, bid_count = bid_count + 1 WHERE id = $item";
			$updateHighest = mysqli_query($conn, $updateHighestQ);
			if($bidNow){
				echo 1;
			}
		}else{
			echo 5;
		}
	} 
}else{
	echo mysqli_error($conn);
}
?>	